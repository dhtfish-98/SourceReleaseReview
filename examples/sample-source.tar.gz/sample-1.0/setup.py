raise RuntimeError('archived source must never execute')
