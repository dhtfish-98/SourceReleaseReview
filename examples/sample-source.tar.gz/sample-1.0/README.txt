Synthetic source release example.
